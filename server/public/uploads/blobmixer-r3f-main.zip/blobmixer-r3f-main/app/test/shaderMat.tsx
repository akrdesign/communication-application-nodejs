// import { shaderMaterial } from "@react-three/drei";
// import { extend } from "@react-three/fiber";

// const Shader = shaderMaterial({}, ``, ``);

// extend({ Shader });

// const TestShaderMat = () => {
//   return (
//     <mesh>
//       <sphereGeometry />
//       <shader />
//     </mesh>
//   );
// };

// export default TestShaderMat;
// //
